CREATE TABLE test2 (id INTEGER PRIMARY KEY, title TEXT);
INSERT INTO test2 (id, title) VALUES (1, 'Hello');
INSERT INTO test2 (id, title) VALUES (2, 'World');