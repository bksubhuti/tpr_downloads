CREATE TABLE test1 (id INTEGER PRIMARY KEY, name TEXT);
INSERT INTO test1 (id, name) VALUES (1, 'Alice');
INSERT INTO test1 (id, name) VALUES (2, 'Bob');